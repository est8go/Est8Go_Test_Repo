import re
import calendar
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from sqlalchemy.exc import IntegrityError
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone, timedelta

from app.database.db import get_db
from app.users.models import User, PLATFORM_ROLES
from app.tenants.models import Tenant
from app.auth.deps import require_platform_user, require_superuser
from app.listings.models import Listing
from app.conversations.models import Conversation
from app.database.audit import log_action
from app.credits.models import MmefTracking, CreditTransaction, CreditWallet

router = APIRouter(prefix="/admin", tags=["Super Admin"])


# ================================================================
# SCHEMAS
# ================================================================

class TrustBadges(BaseModel):
    emerald: int = 0
    gold: int = 0
    silver: int = 0
    unverified: int = 0


class PulseResponse(BaseModel):
    total_tenants: int
    active_tenants: int
    total_listings: int
    verified_listings: int
    pending_queue: int
    avg_trust_score: float
    daily_conversations: int
    daily_inspections: int
    ai_calls_today: int
    active_realtors: int
    ignored_leads: int
    human_takeovers: int
    risk_count: int
    badges: TrustBadges
    risk_alerts: list


class CreateTenantRequest(BaseModel):
    name: str
    business_name: Optional[str] = None
    tenant_type: str = "agency"
    plan: str = "pilot"
    whatsapp_phone_number_id: Optional[str] = None
    admin_email: str
    admin_password: str


class TenantListItem(BaseModel):
    id: int
    name: str
    tenant_type: str
    plan: str
    is_active: bool
    listings_count: int = 0
    users_count: int = 0
    health_score: int = 75

    class Config:
        from_attributes = True


class SuspendTenantRequest(BaseModel):
    reason: str


class DeleteTenantRequest(BaseModel):
    reason: str
    confirm: str  # must equal "DELETE"


class ChangeStaffRoleRequest(BaseModel):
    role: str


class UpdateStaffPhoneRequest(BaseModel):
    phone: str


class UpdateTenantRequest(BaseModel):
    name:                     Optional[str] = None
    business_name:            Optional[str] = None
    tenant_type:              Optional[str] = None
    plan:                     Optional[str] = None
    whatsapp_phone_number:    Optional[str] = None
    whatsapp_phone_number_id: Optional[str] = None
    areas_covered:            Optional[str] = None
    tone:                     Optional[str] = None
    slug:                     Optional[str] = None


class SuperAddStaffRequest(BaseModel):
    email:        str
    password:     str
    role:         str = "realtor"
    first_name:   Optional[str] = None
    phone_number: Optional[str] = None


# ================================================================
# PULSE — platform health snapshot
# ================================================================

@router.get("/pulse", response_model=PulseResponse)
def get_pulse(
    current_user: User = Depends(require_platform_user),
    db: Session = Depends(get_db),
):
    """Platform health snapshot for the command center header."""

    total_tenants  = db.query(Tenant).count()
    active_tenants = db.query(Tenant).filter(Tenant.is_active == True).count()
    total_listings = db.query(Listing).count()

    # Trust grade distribution
    emerald = db.query(Listing).filter(Listing.trust_grade == "Emerald").count()
    gold    = db.query(Listing).filter(Listing.trust_grade == "Gold").count()
    silver  = db.query(Listing).filter(Listing.trust_grade == "Silver").count()

    verified_listings = emerald + gold + silver
    pending_queue     = db.query(Listing).filter(
        Listing.trust_grade.is_(None)
    ).count()
    unverified        = total_listings - verified_listings

    # Average trust score
    avg_score_row = db.query(func.avg(Listing.trust_score)).scalar()
    avg_trust_score = round(float(avg_score_row or 0), 1)

    # Risk count = listings flagged or with very low trust score
    risk_count = db.query(Listing).filter(Listing.trust_score < 30).count()

    return {
        "total_tenants":       total_tenants,
        "active_tenants":      active_tenants,
        "total_listings":      total_listings,
        "verified_listings":   verified_listings,
        "pending_queue":       pending_queue,
        "avg_trust_score":     avg_trust_score,
        "daily_conversations": 0,   # wire to Message model when ready
        "daily_inspections":   0,   # wire to Inspection model when ready
        "ai_calls_today":      0,   # wire to AI usage tracker when ready
        "active_realtors":     0,   # wire to session/activity tracker
        "ignored_leads":       0,
        "human_takeovers":     0,
        "risk_count":          risk_count,
        "badges": {
            "emerald":    emerald,
            "gold":       gold,
            "silver":     silver,
            "unverified": unverified,
        },
        "risk_alerts": [],  # wire to risk detection engine when ready
    }


# ================================================================
# TENANTS — list all
# ================================================================

@router.get("/tenants")
def list_tenants(
    current_user: User = Depends(require_platform_user),
    db: Session = Depends(get_db),
):
    """List all tenants with enriched stats."""
    tenants = db.query(Tenant).order_by(desc(Tenant.created_at)).all()

    result = []
    for t in tenants:
        listings_count = db.query(Listing).filter(Listing.tenant_id == t.id).count()
        users_count    = db.query(User).filter(User.tenant_id == t.id).count()

        result.append({
            "id":                       t.id,
            "name":                     t.name,
            "business_name":            t.business_name,
            "tenant_type":              t.tenant_type,
            "plan":                     t.plan,
            "is_active":                t.is_active,
            "listings_count":           listings_count,
            "users_count":              users_count,
            "health_score":             75,
            "created_at":               str(t.created_at) if t.created_at else None,
            "whatsapp_phone_number":    t.whatsapp_phone_number,
            "whatsapp_phone_number_id": t.whatsapp_phone_number_id,
            "areas_covered":            t.areas_covered,
            "tone":                     t.tone,
            "slug":                     t.slug,
        })
    return result


# ================================================================
# TENANTS — create with admin user (superuser only)
# ================================================================

@router.post("/tenants")
def create_tenant(
    payload: CreateTenantRequest,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """
    Onboard a new tenant and create their first admin user in one shot.
    Superuser only.
    """
    from app.core.security import hash_password

    # ── STEP 1: Required fields not empty ────────────────────────
    required = {
        "name":          payload.name,
        "business_name": payload.business_name or payload.name,
        "plan":          payload.plan,
    }
    for field, value in required.items():
        if not value or not str(value).strip():
            raise HTTPException(status_code=400, detail=f"{field} is required and cannot be empty.")

    # ── STEP 2: Admin email format + uniqueness ───────────────────
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if payload.admin_email:
        if not re.match(email_pattern, payload.admin_email):
            raise HTTPException(status_code=400, detail="Invalid email address format.")
        existing_user = db.query(User).filter(
            User.email == payload.admin_email.lower().strip()
        ).first()
        if existing_user:
            raise HTTPException(status_code=400, detail=f"Email {payload.admin_email} is already registered.")

    # ── STEP 3: WhatsApp number uniqueness ───────────────────────
    if payload.whatsapp_phone_number_id:
        wa = str(payload.whatsapp_phone_number_id).strip()
        existing_wa = db.query(Tenant).filter(
            Tenant.whatsapp_phone_number_id == wa,
            Tenant.is_active == True,
        ).first()
        if existing_wa:
            raise HTTPException(
                status_code=400,
                detail=f"WhatsApp number {wa} is already registered to {existing_wa.business_name}.",
            )
        payload.whatsapp_phone_number_id = wa
    else:
        payload.whatsapp_phone_number_id = None

    # ── STEP 4: Phone number format (if field present) ───────────
    if hasattr(payload, "phone") and payload.phone:
        phone_clean = re.sub(r"[\s\-\(\)]", "", str(payload.phone).strip())
        phone_valid = (
            re.match(r"^0[789][01]\d{8}$", phone_clean) or
            re.match(r"^\+?234[789][01]\d{8}$", phone_clean)
        )
        if not phone_valid:
            raise HTTPException(
                status_code=400,
                detail="Invalid Nigerian phone number format. Use 08012345678 or +2348012345678.",
            )

    # ── STEP 5: Plan is one of allowed values ─────────────────────
    allowed_plans = ["pilot", "access", "growth", "business", "enterprise"]
    if payload.plan and payload.plan.lower() not in allowed_plans:
        raise HTTPException(
            status_code=400,
            detail=f"Plan must be one of: {', '.join(allowed_plans)}",
        )

    # ── STEP 6: Business name uniqueness ─────────────────────────
    biz_name = (payload.business_name or payload.name).strip()
    existing_biz = db.query(Tenant).filter(
        Tenant.business_name == biz_name,
        Tenant.is_active == True,
    ).first()
    if existing_biz:
        raise HTTPException(
            status_code=400,
            detail=f"A tenant named '{biz_name}' already exists.",
        )

    # ── STEP 7: Safe defaults ─────────────────────────────────────
    business_name = biz_name
    tenant_name   = (payload.name or business_name).strip()
    admin_email   = payload.admin_email.lower().strip() if payload.admin_email else ""

    # ── STEP 8: Validate tenant type ─────────────────────────────
    valid_types = ("agency", "freelance", "developer", "investor")
    if payload.tenant_type not in valid_types:
        raise HTTPException(status_code=400, detail="Invalid tenant type.")

    # ── CREATE TENANT + USER (wrapped in single IntegrityError catch) ──
    try:
        tenant = Tenant(
            name=tenant_name,
            business_name=business_name,
            tenant_type=payload.tenant_type,
            plan=payload.plan.lower(),
            whatsapp_phone_number_id=payload.whatsapp_phone_number_id,
            is_active=True,
        )
        db.add(tenant)
        db.flush()  # get tenant.id before creating user

        admin = User(
            tenant_id=tenant.id,
            email=admin_email,
            hashed_password=hash_password(payload.admin_password),
            role="admin",
            is_active=True,
            is_platform_user=False,
            is_admin=True,  # legacy flag
        )
        db.add(admin)
        db.commit()

    except IntegrityError as e:
        db.rollback()
        err = str(e.orig).lower()
        if "whatsapp_phone_number_id" in err:
            raise HTTPException(status_code=400, detail="WhatsApp number already registered to another tenant.")
        if "email" in err:
            raise HTTPException(status_code=400, detail="Email address already registered.")
        if "business_name" in err:
            raise HTTPException(status_code=400, detail="Business name already exists.")
        raise HTTPException(status_code=400, detail="Creation failed: duplicate data detected.")

    # Log the action
    log_action(db, actor=current_user, action="tenant_created",
               target_table="tenants", target_id=tenant.id,
               new_value={"name": tenant.name, "type": tenant.tenant_type})

    return {
        "success": True,
        "message": f"Tenant '{tenant.name}' created successfully.",
        "tenant_id": tenant.id,
        "admin_email": admin.email,
    }


# ================================================================
# TENANTS — update (superuser only)
# ================================================================

@router.patch("/tenants/{tenant_id}")
def update_tenant(
    tenant_id: int,
    payload: UpdateTenantRequest,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """Partial update of any tenant field. Superuser only."""
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found.")

    old_values = {}
    new_values = {}

    if payload.name is not None:
        name = payload.name.strip()
        if not name:
            raise HTTPException(status_code=400, detail="name cannot be empty.")
        dup = db.query(Tenant).filter(Tenant.name == name, Tenant.id != tenant_id).first()
        if dup:
            raise HTTPException(status_code=400, detail=f"A tenant with name '{name}' already exists.")
        old_values["name"] = tenant.name
        tenant.name = name
        new_values["name"] = name

    if payload.business_name is not None:
        bname = payload.business_name.strip()
        if not bname:
            raise HTTPException(status_code=400, detail="business_name cannot be empty.")
        dup = db.query(Tenant).filter(Tenant.business_name == bname, Tenant.id != tenant_id).first()
        if dup:
            raise HTTPException(status_code=400, detail=f"Business name '{bname}' is already taken.")
        old_values["business_name"] = tenant.business_name
        tenant.business_name = bname
        new_values["business_name"] = bname

    if payload.tenant_type is not None:
        valid_types = ("agency", "freelance", "developer", "investor")
        if payload.tenant_type not in valid_types:
            raise HTTPException(status_code=400, detail=f"tenant_type must be one of: {', '.join(valid_types)}")
        old_values["tenant_type"] = tenant.tenant_type
        tenant.tenant_type = payload.tenant_type
        new_values["tenant_type"] = payload.tenant_type

    if payload.plan is not None:
        valid_plans = ("pilot", "access", "growth", "business", "enterprise")
        if payload.plan.lower() not in valid_plans:
            raise HTTPException(status_code=400, detail=f"plan must be one of: {', '.join(valid_plans)}")
        old_values["plan"] = tenant.plan
        tenant.plan = payload.plan.lower()
        new_values["plan"] = payload.plan.lower()

    if payload.whatsapp_phone_number is not None:
        wa = re.sub(r"[\s\-\(\)]", "", payload.whatsapp_phone_number.strip())
        if wa.startswith("+"):
            wa = wa[1:]
        if not re.match(r"^\d{10,15}$", wa):
            raise HTTPException(status_code=400, detail="whatsapp_phone_number must be E.164 format (10–15 digits, no +).")
        old_values["whatsapp_phone_number"] = tenant.whatsapp_phone_number
        tenant.whatsapp_phone_number = wa
        new_values["whatsapp_phone_number"] = wa

    if payload.whatsapp_phone_number_id is not None:
        wa_id = payload.whatsapp_phone_number_id.strip()
        if wa_id:
            dup = db.query(Tenant).filter(
                Tenant.whatsapp_phone_number_id == wa_id,
                Tenant.id != tenant_id,
            ).first()
            if dup:
                raise HTTPException(
                    status_code=400,
                    detail=f"WhatsApp Phone Number ID '{wa_id}' is already used by another tenant.",
                )
        old_values["whatsapp_phone_number_id"] = tenant.whatsapp_phone_number_id
        tenant.whatsapp_phone_number_id = wa_id or None
        new_values["whatsapp_phone_number_id"] = wa_id or None

    if payload.areas_covered is not None:
        old_values["areas_covered"] = tenant.areas_covered
        tenant.areas_covered = payload.areas_covered.strip()
        new_values["areas_covered"] = tenant.areas_covered

    if payload.tone is not None:
        old_values["tone"] = tenant.tone
        tenant.tone = payload.tone.strip()
        new_values["tone"] = tenant.tone

    if payload.slug is not None:
        slug = payload.slug.strip().lower()
        if slug and not re.match(r"^[a-z0-9][a-z0-9\-]*[a-z0-9]$", slug):
            raise HTTPException(
                status_code=400,
                detail="slug must be lowercase alphanumeric with hyphens only (e.g. my-agency).",
            )
        if slug:
            dup = db.query(Tenant).filter(Tenant.slug == slug, Tenant.id != tenant_id).first()
            if dup:
                raise HTTPException(status_code=400, detail=f"Slug '{slug}' is already taken.")
        old_values["slug"] = tenant.slug
        tenant.slug = slug or None
        new_values["slug"] = slug or None

    if not new_values:
        raise HTTPException(status_code=400, detail="No fields provided to update.")

    db.commit()
    db.refresh(tenant)

    log_action(
        db, actor=current_user, action="tenant_updated",
        target_table="tenants", target_id=tenant.id,
        old_value=old_values, new_value=new_values,
    )

    return {
        "success": True,
        "message": f"Tenant '{tenant.name}' updated.",
        "tenant": {
            "id":                       tenant.id,
            "name":                     tenant.name,
            "business_name":            tenant.business_name,
            "tenant_type":              tenant.tenant_type,
            "plan":                     tenant.plan,
            "is_active":                tenant.is_active,
            "whatsapp_phone_number":    tenant.whatsapp_phone_number,
            "whatsapp_phone_number_id": tenant.whatsapp_phone_number_id,
            "areas_covered":            tenant.areas_covered,
            "tone":                     tenant.tone,
            "slug":                     tenant.slug,
        },
    }


# ================================================================
# TENANTS — add staff to any tenant (superuser only)
# ================================================================

@router.post("/tenants/{tenant_id}/staff")
def super_add_staff(
    tenant_id: int,
    payload: SuperAddStaffRequest,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """
    Superuser adds a staff member to any tenant.
    Enforces seat limits same as tenant self-service.
    Bypasses JWT tenant scope.
    """
    from app.core.security import hash_password
    from app.credits.seat_service import (
        check_can_add_staff,
        get_base_seat_limit,
        purchase_extra_seat,
        EXTRA_SEAT_COST,
    )
    from app.credits.service import get_or_create_wallet

    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(404, "Tenant not found.")

    valid_roles = ("admin", "realtor", "staff", "support", "marketing")
    if payload.role not in valid_roles:
        raise HTTPException(400, f"Invalid role '{payload.role}'.")

    # Enforce seat limits
    allowed, reason = check_can_add_staff(tenant_id, db)
    needs_extra_seat = False

    if not allowed:
        if tenant.tenant_type == "freelance":
            raise HTTPException(403, reason)

        wallet = get_or_create_wallet(tenant_id, db)
        available = wallet.purchased_balance + wallet.bonus_balance - wallet.reserved
        if available < EXTRA_SEAT_COST:
            raise HTTPException(
                402,
                f"{reason} Extra seats cost {EXTRA_SEAT_COST} credits/month. "
                f"Tenant has {available} credits available.",
            )
        needs_extra_seat = True

    user = User(
        tenant_id        = tenant_id,
        email            = payload.email,
        hashed_password  = hash_password(payload.password),
        role             = payload.role,
        first_name       = payload.first_name,
        phone_number     = payload.phone_number,
        is_active        = True,
        is_platform_user = False,
    )
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "A user with this email already exists.")

    db.refresh(user)

    if needs_extra_seat:
        try:
            purchase_extra_seat(
                tenant_id    = tenant_id,
                user_id      = user.id,
                db           = db,
                purchased_by = current_user.id,
            )
        except ValueError as e:
            db.delete(user)
            db.commit()
            raise HTTPException(402, str(e))

    log_action(
        db, actor=current_user, action="staff_added",
        target_table="users", target_id=user.id,
        new_value={
            "tenant_id": tenant_id,
            "email":     user.email,
            "role":      user.role,
        },
    )

    return {
        "success":   True,
        "message":   f"Staff member {user.email} added to {tenant.name}.",
        "user_id":   user.id,
        "email":     user.email,
        "role":      user.role,
        "tenant_id": tenant_id,
    }


# ================================================================
# TENANTS — deactivate (superuser only)
# ================================================================

@router.patch("/tenants/{tenant_id}/deactivate")
def deactivate_tenant(
    tenant_id: int,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found.")

    tenant.is_active = False
    db.commit()

    log_action(db, actor=current_user, action="tenant_deactivated",
               target_table="tenants", target_id=tenant.id,
               old_value={"is_active": True}, new_value={"is_active": False})

    return {"message": f"Tenant '{tenant.name}' has been deactivated."}


# ================================================================
# AUDIT LOGS — read (platform staff can view, not modify)
# ================================================================

@router.get("/audit-logs")
def get_audit_logs(
    limit: int = Query(default=50, le=200),
    action: Optional[str] = None,
    current_user: User = Depends(require_platform_user),
    db: Session = Depends(get_db),
):
    """Retrieve audit logs. Filterable by action type."""
    from app.database.audit import AuditLog

    query = db.query(AuditLog).order_by(desc(AuditLog.created_at))

    if action:
        query = query.filter(AuditLog.action == action)

    logs = query.limit(limit).all()

    return [
        {
            "id":           l.id,
            "actor_email":  l.actor_email,
            "actor_role":   l.actor_role,
            "action":       l.action,
            "target_table": l.target_table,
            "target_id":    l.target_id,
            "old_value":    l.old_value,
            "new_value":    l.new_value,
            "created_at":   str(l.created_at) if l.created_at else None,
        }
        for l in logs
    ]


# ================================================================
# TENANTS — suspend (superuser only)
# ================================================================

@router.patch("/tenants/{tenant_id}/suspend")
def suspend_tenant(
    tenant_id: int,
    payload: SuspendTenantRequest,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """Suspend a tenant and silence their bot. Superuser only."""
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found.")
    if not tenant.is_active:
        raise HTTPException(status_code=400, detail="Tenant is already suspended.")

    tenant.is_active = False
    tenant.suspended_at = datetime.utcnow()

    # Silence all conversations for this tenant
    db.query(Conversation).filter(Conversation.tenant_id == tenant_id).update(
        {"is_bot_active": False}, synchronize_session=False
    )

    db.commit()

    log_action(
        db, actor=current_user, action="tenant_suspended",
        target_table="tenants", target_id=tenant.id,
        old_value={"is_active": True},
        new_value={"is_active": False, "reason": payload.reason},
    )

    return {"success": True, "message": f"Tenant '{tenant.name}' suspended."}


# ================================================================
# TENANTS — reactivate (superuser only)
# ================================================================

@router.patch("/tenants/{tenant_id}/reactivate")
def reactivate_tenant(
    tenant_id: int,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """Reactivate a suspended tenant. Superuser only."""
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found.")
    if tenant.is_active:
        raise HTTPException(status_code=400, detail="Tenant is already active.")

    tenant.is_active = True
    tenant.suspended_at = None   # clear suspension timestamp on reactivation
    db.commit()

    log_action(
        db, actor=current_user, action="tenant_reactivated",
        target_table="tenants", target_id=tenant.id,
        old_value={"is_active": False}, new_value={"is_active": True},
    )

    return {"success": True, "message": f"Tenant '{tenant.name}' reactivated."}


# ================================================================
# TENANTS — soft delete (superuser only)
# ================================================================

@router.delete("/tenants/{tenant_id}")
def delete_tenant(
    tenant_id: int,
    payload: DeleteTenantRequest,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """
    Soft-delete a tenant. Data is preserved for audit.
    Requires confirm='DELETE' in the request body.
    Superuser only.
    """
    if payload.confirm != "DELETE":
        raise HTTPException(
            status_code=400,
            detail="Confirmation value must be exactly 'DELETE'.",
        )

    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found.")

    # Soft delete: deactivate and mark name with deletion timestamp
    deleted_at_str = datetime.utcnow().strftime("%Y-%m-%d")
    tenant.is_active = False

    # Silence all conversations
    db.query(Conversation).filter(Conversation.tenant_id == tenant_id).update(
        {"is_bot_active": False}, synchronize_session=False
    )

    db.commit()

    log_action(
        db, actor=current_user, action="tenant_deleted",
        target_table="tenants", target_id=tenant.id,
        old_value={"is_active": True, "name": tenant.name},
        new_value={
            "is_active": False,
            "reason": payload.reason,
            "deleted_at": deleted_at_str,
        },
    )

    return {"success": True, "message": f"Tenant '{tenant.name}' has been soft-deleted."}


# ================================================================
# STAFF — change role (superuser only)
# ================================================================

@router.patch("/staff/{user_id}/role")
def change_staff_role(
    user_id: int,
    payload: ChangeStaffRoleRequest,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """
    Change a platform staff member's role.
    Cannot demote the last superuser.
    Superuser only.
    """
    if payload.role not in PLATFORM_ROLES:
        raise HTTPException(
            status_code=400,
            detail=f"Role must be one of: {', '.join(PLATFORM_ROLES)}.",
        )

    user = db.query(User).filter(
        User.id == user_id, User.is_platform_user == True
    ).first()
    if not user:
        raise HTTPException(status_code=404, detail="Platform staff member not found.")

    # Prevent demoting the last superuser
    if user.role == "superuser" and payload.role != "superuser":
        superuser_count = db.query(User).filter(
            User.is_platform_user == True,
            User.role == "superuser",
            User.is_active == True,
        ).count()
        if superuser_count <= 1:
            raise HTTPException(
                status_code=400,
                detail="Cannot demote the last active superuser.",
            )

    old_role = user.role
    user.role = payload.role
    db.commit()

    log_action(
        db, actor=current_user, action="role_changed",
        target_table="users", target_id=user.id,
        old_value={"role": old_role},
        new_value={"role": payload.role},
    )

    return {
        "success": True,
        "message": f"{user.email} role changed from {old_role} to {payload.role}.",
    }


# ================================================================
# STAFF — update phone number (superuser only)
# ================================================================

@router.patch("/staff/{user_id}/phone")
def update_staff_phone(
    user_id: int,
    payload: UpdateStaffPhoneRequest,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """
    Set or update the WhatsApp phone number for a staff/admin user.
    Normalises to E.164 format (e.g. 2348012345678).
    Superuser only.
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    phone_clean = re.sub(r"[\s\-\(\)]", "", payload.phone)
    if phone_clean.startswith("+"):
        phone_clean = phone_clean[1:]
    elif phone_clean.startswith("0"):
        phone_clean = "234" + phone_clean[1:]
    user.phone_number = phone_clean
    db.commit()
    log_action(
        db, actor=current_user, action="staff_phone_updated",
        target_table="users", target_id=user.id,
        new_value={"phone_number": phone_clean},
    )
    return {"success": True, "phone": phone_clean}


# ================================================================
# STAFF — list all tenant staff (superuser only)
# ================================================================

@router.get("/staff")
def list_staff(
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """
    Returns all tenant (non-platform) users ordered by tenant.
    Used by Super Admin to manage lead-alert phone numbers.
    """
    users = (
        db.query(User)
        .filter(User.is_platform_user == False, User.is_active == True)
        .order_by(User.tenant_id, User.id)
        .all()
    )
    result = []
    for u in users:
        tenant = db.query(Tenant).filter(Tenant.id == u.tenant_id).first()
        result.append({
            "id":           u.id,
            "email":        u.email,
            "role":         u.role,
            "tenant_id":    u.tenant_id,
            "tenant_name":  tenant.business_name if tenant else "—",
            "phone_number": u.phone_number or None,
            "has_phone":    bool(u.phone_number),
            "created_at":   u.created_at.isoformat() if u.created_at else None,
        })
    return result


# ================================================================
# VERIFY QUEUE — pending listings with images + GPS + docs
# ================================================================

@router.get("/verify-queue")
def get_verify_queue(
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    """Return listings that are not yet verified. Superuser only."""
    from app.listings.models import ListingImage

    listings = (
        db.query(Listing)
        .filter(Listing.status.notin_(["verified", "rejected", "flagged"]))
        .order_by(desc(Listing.created_at))
        .limit(50)
        .all()
    )

    result = []
    for l in listings:
        images = db.query(ListingImage).filter(ListingImage.listing_id == l.id).all()
        tenant = db.query(Tenant).filter(Tenant.id == l.tenant_id).first()
        result.append({
            "id":             l.id,
            "title":          l.title,
            "location":       l.location,
            "price":          l.price,
            "property_type":  l.property_type,
            "trust_score":    l.trust_score,
            "trust_grade":    l.trust_grade,
            "status":         l.status,
            "latitude":       l.latitude,
            "longitude":      l.longitude,
            "cof_uploaded":   l.cof_uploaded,
            "survey_uploaded": l.survey_uploaded,
            "deed_uploaded":  l.deed_uploaded,
            "gps_verified_at": l.gps_verified_at.isoformat() if l.gps_verified_at else None,
            "created_at":     l.created_at.isoformat() if l.created_at else None,
            "tenant_name":    tenant.business_name if tenant else "—",
            "images":         [{"url": img.url} for img in images],
        })
    return result


# ================================================================
# LISTINGS — verify / flag / reject (superuser only)
# ================================================================

@router.patch("/listings/{listing_id}/verify")
def verify_listing(
    listing_id: int,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    listing = db.query(Listing).filter(Listing.id == listing_id).first()
    if not listing:
        raise HTTPException(status_code=404, detail="Listing not found.")
    listing.status = "verified"
    db.commit()
    log_action(db, actor=current_user, action="listing_verified",
               target_table="listings", target_id=listing.id,
               new_value={"status": "verified"})
    return {"success": True}


@router.patch("/listings/{listing_id}/flag")
def flag_listing(
    listing_id: int,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    listing = db.query(Listing).filter(Listing.id == listing_id).first()
    if not listing:
        raise HTTPException(status_code=404, detail="Listing not found.")
    listing.status     = "flagged"
    listing.trust_grade = "flagged"
    db.commit()
    log_action(db, actor=current_user, action="listing_flagged",
               target_table="listings", target_id=listing.id,
               new_value={"status": "flagged"})
    return {"success": True}


@router.patch("/listings/{listing_id}/reject")
def reject_listing(
    listing_id: int,
    current_user: User = Depends(require_superuser),
    db: Session = Depends(get_db),
):
    listing = db.query(Listing).filter(Listing.id == listing_id).first()
    if not listing:
        raise HTTPException(status_code=404, detail="Listing not found.")
    listing.status = "rejected"
    db.commit()
    log_action(db, actor=current_user, action="listing_rejected",
               target_table="listings", target_id=listing.id,
               new_value={"status": "rejected"})
    return {"success": True}


# ================================================================
# MMEF COMPLIANCE — monitor Core & Growth tenants
# ================================================================

_MMEF_THRESHOLDS = {"core": 2500, "growth": 6000}


@router.get("/mmef/compliance")
def get_mmef_compliance(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_superuser),
):
    """Returns MMEF compliance status for all Core and Growth tenants."""
    current_month = datetime.utcnow().strftime("%Y-%m")
    now = datetime.utcnow()
    days_in_month = calendar.monthrange(now.year, now.month)[1]
    days_left = days_in_month - now.day

    tenants = db.query(Tenant).filter(
        Tenant.plan.in_(["core", "growth"]),
        Tenant.is_active == True,
    ).all()

    results = []
    for tenant in tenants:
        threshold = _MMEF_THRESHOLDS.get(tenant.plan, 0)

        purchased = db.query(
            func.sum(CreditTransaction.amount_ngn)
        ).filter(
            CreditTransaction.tenant_id == tenant.id,
            CreditTransaction.status == "completed",
            CreditTransaction.month_year == current_month,
        ).scalar() or 0

        mmef = db.query(MmefTracking).filter(
            MmefTracking.tenant_id == tenant.id,
            MmefTracking.month_year == current_month,
        ).first()

        pct = round((purchased / threshold) * 100) if threshold > 0 else 100

        if purchased >= threshold:
            status = "compliant"
        elif mmef and mmef.grace_until and mmef.grace_until > now:
            status = "grace_period"
        elif pct >= 70:
            status = "at_risk"
        else:
            status = "non_compliant"

        wallet = db.query(CreditWallet).filter(
            CreditWallet.tenant_id == tenant.id
        ).first()

        results.append({
            "tenant_id":      tenant.id,
            "tenant_name":    tenant.business_name or "—",
            "plan":           tenant.plan,
            "threshold_ngn":  threshold,
            "purchased_ngn":  purchased,
            "percentage":     min(pct, 100),
            "status":         status,
            "days_left":      days_left,
            "grace_until":    mmef.grace_until.isoformat() if mmef and mmef.grace_until else None,
            "credit_balance": (wallet.purchased_balance + wallet.bonus_balance) if wallet else 0,
            "month_year":     current_month,
        })

    order = {"non_compliant": 0, "at_risk": 1, "grace_period": 2, "compliant": 3}
    results.sort(key=lambda x: order.get(x["status"], 4))

    return {
        "month_year":    current_month,
        "total":         len(results),
        "compliant":     sum(1 for r in results if r["status"] == "compliant"),
        "at_risk":       sum(1 for r in results if r["status"] == "at_risk"),
        "grace":         sum(1 for r in results if r["status"] == "grace_period"),
        "non_compliant": sum(1 for r in results if r["status"] == "non_compliant"),
        "tenants":       results,
    }


@router.post("/mmef/{tenant_id}/override")
def mmef_override(
    tenant_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_superuser),
):
    """Super Admin manually marks a tenant as MMEF compliant for current month."""
    current_month = datetime.utcnow().strftime("%Y-%m")

    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    threshold = _MMEF_THRESHOLDS.get(tenant.plan, 0)

    mmef = db.query(MmefTracking).filter(
        MmefTracking.tenant_id == tenant_id,
        MmefTracking.month_year == current_month,
    ).first()

    if mmef:
        mmef.met = True
        mmef.purchased_ngn = threshold
    else:
        mmef = MmefTracking(
            tenant_id=tenant_id,
            month_year=current_month,
            tier=tenant.plan,
            required_ngn=threshold,
            purchased_ngn=threshold,
            met=True,
        )
        db.add(mmef)

    db.commit()
    log_action(
        db, actor=current_user, action="mmef_override",
        target_table="mmef_tracking", target_id=tenant_id,
        new_value={"month_year": current_month, "met": True},
    )
    return {"success": True, "message": f"MMEF override applied for {tenant.business_name}"}


@router.post("/mmef/{tenant_id}/extend-grace")
def mmef_extend_grace(
    tenant_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_superuser),
):
    """Extend grace period by 7 days for a tenant."""
    current_month = datetime.utcnow().strftime("%Y-%m")

    mmef = db.query(MmefTracking).filter(
        MmefTracking.tenant_id == tenant_id,
        MmefTracking.month_year == current_month,
    ).first()

    if mmef:
        new_grace = (mmef.grace_until or datetime.utcnow()) + timedelta(days=7)
        mmef.grace_until = new_grace
    else:
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        mmef = MmefTracking(
            tenant_id=tenant_id,
            month_year=current_month,
            tier=tenant.plan if tenant else "core",
            required_ngn=_MMEF_THRESHOLDS.get(tenant.plan if tenant else "core", 2500),
            grace_until=datetime.utcnow() + timedelta(days=7),
        )
        db.add(mmef)

    db.commit()
    log_action(
        db, actor=current_user, action="mmef_grace_extended",
        target_table="mmef_tracking", target_id=tenant_id,
        new_value={"month_year": current_month, "grace_days": 7},
    )
    return {"success": True, "message": "Grace period extended by 7 days"}


# ================================================================
# MARKET INTELLIGENCE
# ================================================================

@router.get("/market-intelligence", tags=["Super Admin"])
async def get_market_intelligence(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_superuser),
):
    """
    Market intelligence for the Super Admin.
    Returns price trends by location, trust score distribution,
    transaction volume, and property type breakdown.
    """

    total_listings = db.query(Listing).count()
    avg_price_val  = db.query(func.avg(Listing.price)).scalar()
    avg_trust_val  = db.query(func.avg(Listing.trust_score)).scalar()

    # Gold+ = score >= 70 (gold or emerald)
    verified_count = db.query(Listing).filter(Listing.trust_score >= 70).count()

    # Price & trust by location (top 20 by volume)
    # Group by lowercased location to merge "Guzape" and "guzape" etc.
    loc_rows = (
        db.query(
            func.lower(Listing.location).label("location_lower"),
            func.count(Listing.id).label("count"),
            func.avg(Listing.price).label("avg_price"),
            func.min(Listing.price).label("min_price"),
            func.max(Listing.price).label("max_price"),
            func.avg(Listing.trust_score).label("avg_trust"),
        )
        .filter(Listing.location.isnot(None))
        .group_by(func.lower(Listing.location))
        .order_by(func.count(Listing.id).desc())
        .limit(20)
        .all()
    )

    # Trust grade distribution
    trust_dist = {
        grade: db.query(Listing).filter(Listing.trust_grade == grade).count()
        for grade in ("emerald", "gold", "silver", "bronze", "ungraded")
    }

    # By property type
    type_rows = (
        db.query(
            Listing.property_type,
            func.count(Listing.id).label("count"),
            func.avg(Listing.price).label("avg_price"),
            func.avg(Listing.trust_score).label("avg_trust"),
        )
        .filter(Listing.property_type.isnot(None))
        .group_by(Listing.property_type)
        .order_by(func.count(Listing.id).desc())
        .all()
    )

    # Top listings by trust score
    top_listings = (
        db.query(Listing)
        .filter(Listing.trust_score > 0)
        .order_by(Listing.trust_score.desc())
        .limit(5)
        .all()
    )

    return {
        "summary": {
            "total_listings":  total_listings,
            "avg_price":       round(float(avg_price_val  or 0)),
            "avg_trust_score": round(float(avg_trust_val  or 0), 1),
            "verified_count":  verified_count,
        },
        "price_by_location": [
            {
                "location":  row.location_lower.title() if row.location_lower else "—",
                "count":     row.count,
                "avg_price": round(float(row.avg_price or 0)),
                "min_price": round(float(row.min_price or 0)),
                "max_price": round(float(row.max_price or 0)),
                "avg_trust": round(float(row.avg_trust or 0), 1),
            }
            for row in loc_rows
        ],
        "trust_distribution": trust_dist,
        "by_property_type": [
            {
                "type":      row.property_type,
                "count":     row.count,
                "avg_price": round(float(row.avg_price or 0)),
                "avg_trust": round(float(row.avg_trust or 0), 1),
            }
            for row in type_rows
        ],
        "top_listings": [
            {
                "id":          l.id,
                "title":       l.title,
                "location":    (l.location or "—").title(),
                "trust_score": l.trust_score,
                "trust_grade": l.trust_grade or "ungraded",
                "price":       l.price or 0,
            }
            for l in top_listings
        ],
    }
