from sqlalchemy.orm import Session
from passlib.context import CryptContext
from app.database.db import SessionLocal
from app.users.models import User

# (Tenant import is removed)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def main():
    db: Session = SessionLocal()

    ADMIN_EMAIL = "admin@bravieshomz.com"
    ADMIN_PASSWORD = "test123"

    try:
        print("🛠 Repairing Admin Access...")

        user = db.query(User).filter(User.email == ADMIN_EMAIL).first()
        if not user:
            print(f"❌ User {ADMIN_EMAIL} not found.")
            return

        # 1. Update Password with 72-char safety truncate
        user.hashed_password = pwd_context.hash(ADMIN_PASSWORD[:72])

        # 2. Set Status
        user.is_active = True
        user.is_admin = True
        user.is_superuser = True

        db.commit()
        print(f"✅ Success! Admin {ADMIN_EMAIL} is ready for login.")

    except Exception as e:
        print(f"❌ Error: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    main()
