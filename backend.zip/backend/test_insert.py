from app.database.db import SessionLocal
from app.listings.models import Listing

db = SessionLocal()

listing = Listing(
    tenant_id=1,
    title="Prime Land in Guzape",
    location="Guzape",
    property_type="land",
    price=5000000,
    image_url="https://via.placeholder.com/300",
    description="Dry land with good road access"
)

db.add(listing)
db.commit()
db.close()

print("✅ Listing inserted successfully")